
package org.josepirir.controller;


public class MenuPrincipalController {
    
}
