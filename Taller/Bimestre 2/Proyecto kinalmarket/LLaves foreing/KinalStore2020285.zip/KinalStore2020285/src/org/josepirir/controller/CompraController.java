
package org.josepirir.controller;

import eu.schudt.javafx.controls.calendar.DatePicker;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javax.swing.JOptionPane;

import org.josepirir.bean.Compra;
import org.josepirir.db.Conexion;
import org.josepirir.system.Principal;


public class CompraController implements Initializable{
     private Principal escenarioPrincipal;
    
    private enum operaciones{NUEVO,ELIMINAR,ACTUALIZAR,GUARDAR,NINGUNO}
    private operaciones tipoOperacion=operaciones.NINGUNO;
    private ObservableList<Compra> listaCompra;
    private DatePicker fecha;
    
    @FXML private TableView tblCompras;
    
    @FXML private GridPane grpFecha;
    
    @FXML private TextField txtNumeroDocumento;
    @FXML private TextField txtDescripcion;
    @FXML private TextField txtTotalDocumento;
    
    @FXML private TableColumn colNumeroDocumento;
    @FXML private TableColumn colFechaDocumento;
    @FXML private TableColumn colDescripcion;
    @FXML private TableColumn colTotalDocumento;
    
    @FXML private Button btnNuevo;
    @FXML private Button btnEliminar;
    @FXML private Button btnEditar;
    @FXML private Button btnReporte;
    
    @FXML private ImageView imgNuevo;
    @FXML private ImageView imgEliminar;
    @FXML private ImageView imgEditar;
    @FXML private ImageView imgReporte;
            
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        fecha = new DatePicker(Locale.ENGLISH);
        fecha.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
        fecha.getCalendarView().todayButtonTextProperty().set("Today");
        fecha.getCalendarView().setShowWeeks(false);
        fecha.getStylesheets().add("/org/josepirir/resource/KinalStoreCSS.css");
        grpFecha.add(fecha,3,0);
    }
    
    public void seleccionarElemento(){
        if(tblCompras.getSelectionModel().getSelectedItem()!=null){
            txtNumeroDocumento.setText(String.valueOf(((Compra)tblCompras.getSelectionModel().getSelectedItem()).getNumeroDocumento()));
            fecha.selectedDateProperty().set(((Compra)tblCompras.getSelectionModel().getSelectedItem()).getFechaDocumento());
            txtDescripcion.setText(((Compra)tblCompras.getSelectionModel().getSelectedItem()).getDescripcion());
            txtTotalDocumento.setText(String.valueOf(((Compra)tblCompras.getSelectionModel().getSelectedItem()).getTotalDocumento()));
        }else
            JOptionPane.showMessageDialog(null, "Tiene que seleccionar un elemento");
    }
    
    
    public void cargarDatos(){
        tblCompras.setItems(getCompra());
        colNumeroDocumento.setCellValueFactory(new PropertyValueFactory<Compra,Integer>("numeroDocumento"));
        colFechaDocumento.setCellValueFactory(new PropertyValueFactory<Compra,Date>("fechaDocumento"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<Compra,String>("descripcion"));
        colTotalDocumento.setCellValueFactory(new PropertyValueFactory<Compra,String>("totalDocumento"));
    }
    
    public ObservableList<Compra> getCompra(){
        ArrayList<Compra>lista=new ArrayList<Compra>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_ListarCompras}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Compra(resultado.getInt("numeroDocumento"),
                    resultado.getDate("fechaDocumento"),
                    resultado.getString("descripcion"),
                    resultado.getDouble("totalDocumento")));
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaCompra = FXCollections.observableArrayList(lista);
    }
    
    
    
    public void nuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                activarControles();
                limpiarControles();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                imgNuevo.setImage(new Image("/org/josepirir/image/guardar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/cancelar.png"));
                tipoOperacion = operaciones.GUARDAR;
            break;
            case GUARDAR:
                guardar();
                limpiarControles();
                desactivarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                imgNuevo.setImage(new Image("/org/josepirir/image/Agregar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/Eliminar.png"));
                tipoOperacion = operaciones.NINGUNO;
                cargarDatos();
            break;
        }
    }
    
    public void guardar(){
        if(!txtNumeroDocumento.getText().isEmpty() && fecha.getSelectedDate() !=null && !txtDescripcion.getText().isEmpty()){
            Compra registro = new Compra();
            registro.setNumeroDocumento(Integer.parseInt(txtNumeroDocumento.getText()));
            registro.setFechaDocumento(fecha.getSelectedDate());
            registro.setDescripcion(txtDescripcion.getText());
            try{
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregarCompra(?,?,?)}");
                procedimiento.setInt(1, registro.getNumeroDocumento());
                procedimiento.setDate(2, new java.sql.Date(registro.getFechaDocumento().getTime()));
                procedimiento.setString(3, registro.getDescripcion());
                procedimiento.execute();
                listaCompra.add(registro);
            }catch(Exception e){
                e.printStackTrace();
            }
        }else
            JOptionPane.showMessageDialog(null, "Tienes que llenar todos los campos");
    }
    
    public void eliminar(){
        switch(tipoOperacion){
            case GUARDAR:
                limpiarControles();
                desactivarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                imgNuevo.setImage(new Image("/org/josepirir/image/Agregar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/Eliminar.png"));
                tipoOperacion = operaciones.NINGUNO;
            break;
            default:
                if(tblCompras.getSelectionModel().getSelectedItem()!=null){
                    int respuesta = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar el registro?","Eliminar Cliente",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                    if(respuesta==JOptionPane.YES_OPTION){
                        try{
                            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{Call sp_EliminarCompra(?)}");
                            procedimiento.setInt(1, ((Compra)tblCompras.getSelectionModel().getSelectedItem()).getNumeroDocumento());
                            procedimiento.execute();
                            listaCompra.remove(tblCompras.getSelectionModel().getSelectedIndex());
                            limpiarControles();
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento");
                }
        }    
    }
    
    public void editar(){
        switch(tipoOperacion){
            case NINGUNO:
                if(tblCompras.getSelectionModel().getSelectedItem()!=null){
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    btnEditar.setText("Actualizar");
                    btnReporte.setText("Cancelar");
                    imgEditar.setImage(new Image("/org/josepirir/image/Actualizar.png"));
                    imgReporte.setImage(new Image("/org/josepirir/image/cancelar.png"));
                    activarControles();
                    tipoOperacion = operaciones.ACTUALIZAR;
                }else
                    JOptionPane.showMessageDialog(null, "Debe Seleccionar Un Elemento");
            break;
            case ACTUALIZAR:
                actualizar();
                limpiarControles();
                desactivarControles();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                imgEditar.setImage(new Image("/org/josepirir/image/Editar.png"));
                imgReporte.setImage(new Image("/org/josepirir/image/Reporte.png"));
                cargarDatos();
                tipoOperacion = operaciones.NINGUNO;
            break;    
        }
    }
    
    public void reporte(){
        switch(tipoOperacion){
            case NINGUNO:
            break;
            case ACTUALIZAR:
                limpiarControles();
                desactivarControles();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                imgEditar.setImage(new Image("/org/josepirir/image/Editar.png"));
                imgReporte.setImage(new Image("/org/josepirir/image/Reporte.png"));
                tipoOperacion = operaciones.NINGUNO;
            break;
        }
    }
    
    public void actualizar(){
        if(!txtNumeroDocumento.getText().isEmpty() && fecha.getSelectedDate() !=null && !txtDescripcion.getText().isEmpty()){
            try{
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_EditarCompra(?,?,?)}");
                Compra registro = (Compra)tblCompras.getSelectionModel().getSelectedItem();
                registro.setFechaDocumento(fecha.getSelectedDate());
                registro.setDescripcion(txtDescripcion.getText());


                procedimiento.setInt(1, registro.getNumeroDocumento());
                procedimiento.setDate(2, (java.sql.Date) registro.getFechaDocumento());
                procedimiento.setString(3, registro.getDescripcion());
                procedimiento.execute();
            }catch(Exception e){
                e.printStackTrace();
            }
        }else
            JOptionPane.showMessageDialog(null, "Tienes que llenar todos los campos");
    }
    
    public void desactivarControles(){
        txtNumeroDocumento.setEditable(false);
        txtDescripcion.setEditable(false);
        txtTotalDocumento.setEditable(false);
        fecha.setDisable(true);
    }
    
    public void activarControles(){
        txtNumeroDocumento.setEditable(true);
        txtDescripcion.setEditable(true);
        txtTotalDocumento.setEditable(true);
        fecha.setDisable(false);
    }
    
    public void limpiarControles(){
        txtNumeroDocumento.clear();
        txtDescripcion.clear();
        txtTotalDocumento.clear();
        fecha.setSelectedDate(null);
    }
    
    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
}