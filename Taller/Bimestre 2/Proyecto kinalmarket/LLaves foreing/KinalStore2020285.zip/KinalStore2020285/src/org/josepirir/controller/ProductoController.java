
package org.josepirir.controller;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javax.swing.JOptionPane;
import org.josepirir.bean.TipoProducto;
import org.josepirir.bean.Productos;
import org.josepirir.bean.Proveedores;
import org.josepirir.db.Conexion;
import org.josepirir.system.Principal;


public class ProductoController implements Initializable{
    private Principal escenarioPrincipal;
    
    private enum operaciones{NUEVO,ELIMINAR,ACTUALIZAR,GUARDAR,NINGUNO}
    private operaciones tipoOperacion=operaciones.NINGUNO;
    private ObservableList<Productos> listaProducto;
    
    @FXML private TableView tblProductos;
    
    @FXML private TextField txtCodigoProducto;
    @FXML private TextField txtDescripcionProducto;
    @FXML private TextField txtPrecioUnitario;
    @FXML private TextField txtPrecioDocena;
    @FXML private TextField txtPrecioMayor;
    @FXML private TextField txtImagenProducto;
    @FXML private TextField txtExistencia;
    
    @FXML private ComboBox cmbCodigoTipoProducto;
    @FXML private ComboBox cmbCodigoProveedor;
    
    @FXML private TableColumn colCodigoProducto;
    @FXML private TableColumn colDescripcionProducto;
    @FXML private TableColumn colPrecioUnitario;
    @FXML private TableColumn colPrecioDocena;
    @FXML private TableColumn colPrecioMayor;
    @FXML private TableColumn colImagenProducto;
    @FXML private TableColumn colExistencia;
    @FXML private TableColumn colCodigoTipoProducto;
    @FXML private TableColumn colCodigoProveedor;
    
    @FXML private Button btnNuevo;
    @FXML private Button btnEliminar;
    @FXML private Button btnEditar;
    @FXML private Button btnReporte;
    
    @FXML private ImageView imgNuevo;
    @FXML private ImageView imgEliminar;
    @FXML private ImageView imgEditar;
    @FXML private ImageView imgReporte;
    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
    }
    
    public void seleccionarElemento(){
        if(tblProductos.getSelectionModel().getSelectedItem()!=null){
            
        }else
            JOptionPane.showMessageDialog(null, "Tiene que seleccionar un elemento");
    }
    
    public void cargarDatos(){
        tblProductos.setItems(getProducto());
        colCodigoProducto.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("codigoProducto"));
        colDescripcionProducto.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("descripcionProducto"));
        colPrecioUnitario.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("precioUnitario"));
        colPrecioDocena.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("precioDocena"));
        colPrecioMayor.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("precioMayor"));
        colImagenProducto.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("imagenProducto"));
        colExistencia.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("existencia"));
        colCodigoTipoProducto.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("codigoTipoProducto"));
        colCodigoProveedor.setCellValueFactory(new PropertyValueFactory<Productos,Integer>("codigoProveedor"));
    }
    
    public ObservableList<Productos> getProducto(){
        ArrayList<Productos> lista = new ArrayList<Productos>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_ListarProductos}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Productos(resultado.getInt("codigoProducto"),
                    resultado.getString("descripcionProducto"),
                    resultado.getDouble("precioUnitario"),
                    resultado.getDouble("precioDocena"),
                    resultado.getDouble("precioMayor"),
                    resultado.getString("imagenProducto"),
                    resultado.getInt("existencia"),
                    resultado.getInt("codigoTipoProducto"),
                    resultado.getInt("codigoProveedor")));
            }
        }catch(Exception e){
            e.printStackTrace();
        }return listaProducto = FXCollections.observableArrayList(lista);
    }
    
    public void nuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                activarControles();
                limpiarControles();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                imgNuevo.setImage(new Image("/org/josepirir/image/guardar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/cancelar.png"));
                tipoOperacion = operaciones.GUARDAR;
            break;
            case GUARDAR:
                guardar();
                limpiarControles();
                desactivarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                imgNuevo.setImage(new Image("/org/josepirir/image/Agregar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/Eliminar.png"));
                tipoOperacion = operaciones.NINGUNO;
                cargarDatos();
            break;
        }
    }
    
    public void guardar(){
        if(!txtDescripcionProducto.getText().isEmpty()){
            try{
                Productos registro = new Productos();
                registro.setDescripcionProducto(txtDescripcionProducto.getText());
                registro.setImagenProducto(txtImagenProducto.getText());
                registro.setCodigoTipoProducto(Integer.parseInt(String.valueOf(((TipoProducto)cmbCodigoTipoProducto.getSelectionModel().getSelectedItem()).getCodigoTipoProducto())));
                registro.setCodigoProveedor(Integer.parseInt(String.valueOf(((Proveedores)cmbCodigoProveedor.getSelectionModel().getSelectedItem()).getCodigoProveedor())));
                
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregarProductos(?,?,?,?)}");
                procedimiento.setString(1, registro.getDescripcionProducto());
                procedimiento.setString(2, registro.getImagenProducto());
                procedimiento.setInt(3, registro.getCodigoTipoProducto());
                procedimiento.setInt(4, registro.getCodigoProveedor());
                procedimiento.execute();
                listaProducto.add(registro);
            }catch(Exception e){
                e.printStackTrace();
            }
        }else 
            JOptionPane.showMessageDialog(null, "Tienes que llenar todos los campos");
    }
    
    public void eliminar(){
        switch(tipoOperacion){
            case GUARDAR:
                limpiarControles();
                desactivarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                imgNuevo.setImage(new Image("/org/josepirir/image/Agregar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/Eliminar.png"));
                tipoOperacion = operaciones.NINGUNO;
            break;
            default:
                if(tblProductos.getSelectionModel().getSelectedItem()!=null){
                    try{
                        PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_EliminarProductos(?)}");
                        procedimiento.setInt(1, ((Productos)tblProductos.getSelectionModel().getSelectedItem()).getCodigoProducto());
                        procedimiento.execute();
                        listaProducto.remove(tblProductos.getSelectionModel().getSelectedIndices());
                        limpiaroControles();
                        cargarDatos();
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            break;
        }
    }
    
    public void editar(){
        switch(tipoOperacion){
            
        }
    }
    
    
    
}
