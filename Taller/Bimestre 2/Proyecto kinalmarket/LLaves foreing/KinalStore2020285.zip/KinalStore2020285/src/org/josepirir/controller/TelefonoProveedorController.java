/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.josepirir.controller;


import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javax.swing.JOptionPane;
import org.josepirir.bean.Proveedores;
import org.josepirir.bean.TelefonoProveedor;
import org.josepirir.db.Conexion;
import org.josepirir.system.Principal;

/**
 *
 * @author informatica
 */
public class TelefonoProveedorController implements Initializable{
    private Principal escenarioPrincipal;
    
    private enum operaciones{NUEVO,ELIMINAR,ACTUALIZAR,GUARDAR,NINGUNO}
    private operaciones tipoOperacion=operaciones.NINGUNO;
    private ObservableList<TelefonoProveedor> listaTelefonoProveedor;
    private ObservableList<Proveedores> listaProveedor;
    
    @FXML private TableView tblTelefonoProveedor;
    
    @FXML private TextField txtCodigoTelefonoProveedor;
    @FXML private TextField txtNumeroPrincipal;
    @FXML private TextField txtNumeroSecundario;
    @FXML private TextField txtObservaciones;
            
    @FXML private ComboBox cmbCodigoProveedor;        
    
    @FXML private TableColumn colCodigoTelefonoProveedor;
    @FXML private TableColumn colNumeroPrincipal;
    @FXML private TableColumn colNumeroSecundario;
    @FXML private TableColumn colObservaciones;
    @FXML private TableColumn colCodigoProveedor;
    
    @FXML private Button btnNuevo;
    @FXML private Button btnEliminar;
    @FXML private Button btnEditar;
    @FXML private Button btnReporte;
    
    @FXML private ImageView imgNuevo;
    @FXML private ImageView imgEliminar;
    @FXML private ImageView imgEditar;
    @FXML private ImageView imgReporte;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        cmbCodigoProveedor.setItems(getProveedor());
    }
    
    public void seleccionarElemento(){
        if(tblTelefonoProveedor.getSelectionModel().getSelectedItem()!=null){
            txtCodigoTelefonoProveedor.setText(String.valueOf(((TelefonoProveedor)tblTelefonoProveedor.getSelectionModel().getSelectedItem()).getCodigoTelefonoProveedor()));
            txtNumeroPrincipal.setText(((TelefonoProveedor)tblTelefonoProveedor.getSelectionModel().getSelectedItem()).getNumeroPrincipal());
            txtNumeroSecundario.setText(((TelefonoProveedor)tblTelefonoProveedor.getSelectionModel().getSelectedItem()).getNumeroSecundario());
            txtObservaciones.setText(((TelefonoProveedor)tblTelefonoProveedor.getSelectionModel().getSelectedItem()).getObservaciones());
            cmbCodigoProveedor.getSelectionModel().select(buscarProveedor(((TelefonoProveedor)tblTelefonoProveedor.getSelectionModel().getSelectedItem()).getCodigoProveedor()));
        }else
            JOptionPane.showMessageDialog(null, "Tiene que seleccionar un elemento");
    }
    
    public void cargarDatos(){
        tblTelefonoProveedor.setItems(getTelefonoProveedor());
        
        colCodigoTelefonoProveedor.setCellValueFactory(new PropertyValueFactory<TelefonoProveedor,Integer>("codigoTelefonoProveedor"));
        colNumeroPrincipal.setCellValueFactory(new PropertyValueFactory<TelefonoProveedor,String>("numeroPrincipal"));
        colNumeroSecundario.setCellValueFactory(new PropertyValueFactory<TelefonoProveedor,String>("numeroSecundario"));
        colObservaciones.setCellValueFactory(new PropertyValueFactory<TelefonoProveedor,String>("observaciones"));
        colCodigoProveedor.setCellValueFactory(new PropertyValueFactory<TelefonoProveedor,Integer>("codigoProveedor"));
    }
    
    public ObservableList<TelefonoProveedor>getTelefonoProveedor(){
        ArrayList<TelefonoProveedor> lista = new ArrayList<TelefonoProveedor>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_ListartelefonoProveedor}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new TelefonoProveedor(resultado.getInt("codigoTelefonoProveedor"),
                    resultado.getString("numeroPrincipal"),
                    resultado.getString("numeroSecundario"),
                    resultado.getString("observaciones"),
                    resultado.getInt("codigoProveedor")));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaTelefonoProveedor = FXCollections.observableArrayList(lista);
    }
    
    public void nuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                activarControles();
                limpiarControles();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                imgNuevo.setImage(new Image("/org/josepirir/image/guardar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/cancelar.png"));
                tipoOperacion = operaciones.GUARDAR;
            break; 
            case GUARDAR:
                guardar();
                limpiarControles();
                desactivarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                imgNuevo.setImage(new Image("/org/josepirir/image/Agregar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/Eliminar.png"));
                tipoOperacion = operaciones.NINGUNO;
                cargarDatos();
            break;
        }
    }
    
    public void guardar(){
        if(!txtNumeroPrincipal.getText().isEmpty() && !txtNumeroSecundario.getText().isEmpty() && !txtObservaciones.getText().isEmpty()){
            
            try{
                TelefonoProveedor registro = new TelefonoProveedor();
                registro.setNumeroPrincipal(txtNumeroPrincipal.getText());
                registro.setNumeroSecundario(txtNumeroSecundario.getText());
                registro.setObservaciones(txtObservaciones.getText());
//                registro.setCodigoProveedor(Integer.parseInt(String.valueOf(((Proveedores)cmbCodigoProveedor.getSelectionModel().getSelectedItem()).getCodigoProveedor())));
                Proveedores seleccion = (Proveedores)cmbCodigoProveedor.getSelectionModel().getSelectedItem();
                registro.setCodigoProveedor(seleccion.getCodigoProveedor());
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregartelefonoProveedor(?,?,?,?)}");
                procedimiento.setString(1, registro.getNumeroPrincipal());
                procedimiento.setString(2, registro.getNumeroSecundario());
                procedimiento.setString(3, registro.getObservaciones());
                procedimiento.setInt(4, registro.getCodigoProveedor());
                procedimiento.execute();
                listaTelefonoProveedor.add(registro);
            }catch(Exception e){
                e.printStackTrace();
            }
        }else
            JOptionPane.showMessageDialog(null, "Tienes que llenar todos los campos");
    }
    
    public void eliminar(){
        switch(tipoOperacion){
            case GUARDAR:
                limpiarControles();
                desactivarControles();
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                imgNuevo.setImage(new Image("/org/josepirir/image/Agregar.png"));
                imgEliminar.setImage(new Image("/org/josepirir/image/Eliminar.png"));
                tipoOperacion = operaciones.NINGUNO;
            break;
            default:
                if(tblTelefonoProveedor.getSelectionModel().getSelectedItem()!=null){
                    int respuesta = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar el registro?","Eliminar Cliente",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                    if(respuesta == JOptionPane.YES_OPTION){
                        try{
                            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_EliminartelefonoProveedor(?)}");
                            procedimiento.setInt(1, ((TelefonoProveedor)tblTelefonoProveedor.getSelectionModel().getSelectedItem()).getCodigoTelefonoProveedor());
                            procedimiento.execute();
                            listaTelefonoProveedor.remove(tblTelefonoProveedor.getSelectionModel().getSelectedIndices());
                            limpiarControles();
                            cargarDatos();
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                }
            break;
        }
    }
    
    public void editar(){
        switch(tipoOperacion){
            case NINGUNO:
                if(tblTelefonoProveedor.getSelectionModel().getSelectedItem()!=null){
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    btnEditar.setText("Actualizar");
                    btnReporte.setText("Cancelar");
                    imgEditar.setImage(new Image("/org/josepirir/image/Actualizar.png"));
                    imgReporte.setImage(new Image("/org/josepirir/image/cancelar.png"));
                    activarControles();
                    tipoOperacion = operaciones.ACTUALIZAR;
                }else
                    JOptionPane.showMessageDialog(null, "Debe Seleccionar Un Elemento");
            break;
            case ACTUALIZAR:
                actualizar();
                limpiarControles();
                desactivarControles();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                imgEditar.setImage(new Image("/org/josepirir/image/Editar.png"));
                imgReporte.setImage(new Image("/org/josepirir/image/Reporte.png"));
                cargarDatos();
                tipoOperacion = operaciones.NINGUNO;
            break;
        }
    }
    
    public void reporte(){
        switch(tipoOperacion){
            case NINGUNO:
            break;
            case ACTUALIZAR:
                limpiarControles();
                desactivarControles();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                imgEditar.setImage(new Image("/org/josepirir/image/Editar.png"));
                imgReporte.setImage(new Image("/org/josepirir/image/Reporte.png"));
                tipoOperacion = operaciones.NINGUNO;
            break;
        }
    }
    
    public void actualizar(){
        if(!txtNumeroPrincipal.getText().isEmpty() && !txtNumeroSecundario.getText().isEmpty() && !txtObservaciones.getText().isEmpty()){
            try{
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_EditartelefonoProveedor(?,?,?,?)}");
                TelefonoProveedor registro = (TelefonoProveedor)tblTelefonoProveedor.getSelectionModel().getSelectedItem();
                registro.setNumeroPrincipal(txtNumeroPrincipal.getText());
                registro.setNumeroSecundario(txtNumeroSecundario.getText());
                registro.setObservaciones(txtObservaciones.getText());
                
                procedimiento.setInt(1, registro.getCodigoTelefonoProveedor());
                procedimiento.setString(2, registro.getNumeroPrincipal());
                procedimiento.setString(3, registro.getNumeroSecundario());
                procedimiento.setString(4, registro.getObservaciones());
                procedimiento.execute();
            }catch(Exception e){
                e.printStackTrace();
            }
        }else
            JOptionPane.showMessageDialog(null, "Tienes que llenar todos los campos");
    }
    
    public Proveedores buscarProveedor(int codigoProveedor){
        Proveedores resultado = null;
        try{
            PreparedStatement procedimiento=Conexion.getInstance().getConexion().prepareCall("{call sp_BuscarProveedores(?)}");
            procedimiento.setInt(1, codigoProveedor);
            ResultSet registro = procedimiento.executeQuery();
            while (registro.next()){
                resultado = new Proveedores(registro.getInt("codigoProveedor"),
                        registro.getString("NITProveedor"),
                        registro.getString("nombresProveedor"),
                        registro.getString("apellidosProveedor"),
                        registro.getString("direccionProveedor"),
                        registro.getString("razonSocial"),
                        registro.getString("contactoProveedor"),
                        registro.getString("paginaWeb"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }return resultado;
    }
    
    public ObservableList<Proveedores> getProveedor(){
        ArrayList<Proveedores> lista=new ArrayList<Proveedores>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_ListarProveedores}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Proveedores(resultado.getInt("codigoProveedor"),
                resultado.getString("NITProveedor"),
                resultado.getString("nombresProveedor"),
                resultado.getString("apellidosProveedor"),
                resultado.getString("direccionProveedor"),
                resultado.getString("razonSocial"),
                resultado.getString("contactoProveedor"),
                resultado.getString("paginaWeb")));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaProveedor = FXCollections.observableArrayList(lista);
    }
    
    public void desactivarControles(){
        txtCodigoTelefonoProveedor.setEditable(false);
        txtNumeroPrincipal.setEditable(false);
        txtNumeroSecundario.setEditable(false);
        txtObservaciones.setEditable(false);
        cmbCodigoProveedor.setEditable(false);
    }
    
    public void activarControles(){
        txtCodigoTelefonoProveedor.setEditable(true);
        txtNumeroPrincipal.setEditable(true);
        txtNumeroSecundario.setEditable(true);
        txtObservaciones.setEditable(true);
        cmbCodigoProveedor.setEditable(true);
    }
    
    public void limpiarControles(){
        txtCodigoTelefonoProveedor.clear();
        txtNumeroPrincipal.clear();
        txtNumeroSecundario.clear();
        txtObservaciones.clear();
        cmbCodigoProveedor.getSelectionModel().clearSelection();
    }
    
    public Principal getEscenarioPrincipal(){
        return escenarioPrincipal;
    }
    
    public void setEscenarioPrincipal(Principal escenarioPrincipal){
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void ventanaProveedor(){
        escenarioPrincipal.ventanaProveedor();
    }
}



